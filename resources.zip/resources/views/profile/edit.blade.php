<x-app-layout>
    <div class="flex min-h-screen bg-slate-50">
        <!-- Sidebar User -->
        <x-user-sidebar />

        <!-- Main Content Wrapper -->
        <div class="flex-1 flex flex-col min-w-0">
            <!-- Top Navbar Search & Profile -->
            <header
                class="bg-white border-b border-slate-100 py-4 px-8 flex items-center justify-between sticky top-0 z-10 shadow-sm">
                <div class="relative w-full max-w-md flex items-center gap-3">
                    <button class="text-slate-500 hover:text-slate-700">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M4 6h16M4 12h16M4 18h16" />
                        </svg>
                    </button>
                    <div class="relative flex-1">
                        <input type="text" placeholder="Cari event, tempat, atau kategori..."
                            class="w-full bg-slate-50 text-xs border-0 rounded-full py-2.5 pl-5 pr-10 focus:ring-2 focus:ring-blue-950 focus:bg-white transition placeholder-slate-400">
                        <svg class="w-4 h-4 text-slate-400 absolute right-4 top-3" fill="none" stroke="currentColor"
                            viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                        </svg>
                    </div>
                </div>

                <div class="flex items-center gap-4">
                    <a href="{{ route('notifications.index') }}"
                        class="relative p-2 text-slate-500 hover:text-slate-700 rounded-full hover:bg-slate-100 transition">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                        </svg>
                        <span
                            class="absolute top-1 right-1 bg-rose-500 text-white text-[10px] font-bold w-4 h-4 flex items-center justify-center rounded-full">2</span>
                    </a>

                    <div class="flex items-center gap-3 pl-2 border-l border-slate-100">
                        <span class="text-xs font-semibold text-slate-700">Halo, <span
                                class="font-bold text-slate-900">{{ $user->name }}</span>!</span>
                        <div
                            class="w-9 h-9 rounded-full bg-blue-950 text-white flex items-center justify-center font-bold text-xs uppercase shadow-sm">
                            {{ substr($user->name, 0, 2) }}
                        </div>
                    </div>
                </div>
            </header>

            <!-- Main Body -->
            <main class="p-8 flex-1 space-y-6">

                <!-- Breadcrumbs & Header Title -->
                <div class="space-y-1">
                    <nav class="flex text-xs text-slate-400 gap-2 items-center">
                        <a href="{{ route('user.dashboard') }}" class="hover:text-slate-800">Beranda</a>
                        <span>&rsaquo;</span>
                        <span class="font-bold text-slate-800">Profil Saya</span>
                    </nav>
                    <h1 class="text-2xl font-black text-slate-900 tracking-tight">Profil Saya</h1>
                    <p class="text-xs text-slate-500">Kelola informasi profil dan lihat riwayat transaksi Anda.</p>
                </div>

                <!-- Tabs Row -->
                <div class="flex items-center gap-6 border-b border-slate-200 text-xs font-bold pb-2">
                    <button class="text-blue-950 border-b-2 border-blue-950 pb-2 -mb-2.5 flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                        </svg>
                        <span>Edit Profil</span>
                    </button>
                    <button class="text-slate-500 hover:text-slate-900 transition flex items-center gap-2">
                        <svg class="w-4 h-4" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M12 8v4l3 3m6-3a9 9 0 11-18 0 9 9 0 0118 0z" />
                        </svg>
                        <span>Riwayat Transaksi</span>
                    </button>
                </div>

                @if(session('status') === 'profile-updated')
                <div
                    class="p-4 bg-emerald-50 border border-emerald-200 text-emerald-800 rounded-2xl text-xs font-medium flex items-center gap-2">
                    <span>✅</span>
                    <span>Informasi profil berhasil diperbarui!</span>
                </div>
                @endif

                <!-- MAIN GRID: LEFT (2 COLS) | RIGHT (1 COL) -->
                <div class="grid grid-cols-1 lg:grid-cols-3 gap-8">

                    <!-- LEFT COLUMN (2 COLS) -->
                    <div class="lg:col-span-2 space-y-8">

                        <!-- 1. Informasi Pribadi Card -->
                        <div class="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-6">
                            <div class="flex items-center justify-between border-b border-slate-100 pb-4">
                                <div>
                                    <h3 class="font-extrabold text-slate-900 text-base">Informasi Pribadi</h3>
                                    <p class="text-xs text-slate-500 mt-0.5">Perbarui informasi pribadi Anda.</p>
                                </div>
                                <button type="button"
                                    class="inline-flex items-center gap-1.5 px-3 py-1.5 border border-slate-200 rounded-xl text-xs font-bold text-slate-700 hover:bg-slate-50 transition shadow-sm">
                                    <svg class="w-3.5 h-3.5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M3 9a2 2 0 012-2h.93a2 2 0 001.664-.89l.812-1.22A2 2 0 0110.07 4h3.86a2 2 0 011.664.89l.812 1.22A2 2 0 0018.07 7H19a2 2 0 012 2v9a2 2 0 01-2 2H5a2 2 0 01-2-2V9z" />
                                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                            d="M15 13a3 3 0 11-6 0 3 3 0 016 0z" />
                                    </svg>
                                    <span>Ubah Foto</span>
                                </button>
                            </div>

                            <form method="POST" action="{{ route('user.profile.update') }}" class="space-y-5">
                                @csrf
                                @method('patch')

                                <!-- Profile Avatar Row -->
                                <div class="flex items-center gap-4">
                                    <div
                                        class="relative w-20 h-20 rounded-full bg-slate-900 text-white flex items-center justify-center font-black text-xl uppercase shadow-md overflow-hidden ring-4 ring-slate-100">
                                        {{ substr($user->name, 0, 2) }}
                                        <div
                                            class="absolute bottom-0 inset-x-0 bg-black/40 py-1 text-center cursor-pointer">
                                            <span class="text-[10px]">📷</span>
                                        </div>
                                    </div>
                                    <div>
                                        <h4 class="font-bold text-slate-900 text-sm">{{ $user->name }}</h4>
                                        <p class="text-xs text-slate-500">{{ $user->email }}</p>
                                    </div>
                                </div>

                                <!-- Form Grid -->
                                <div class="grid grid-cols-1 sm:grid-cols-2 gap-4 text-xs">
                                    <div class="space-y-1">
                                        <label class="font-bold text-slate-700">Nama Lengkap<span
                                                class="text-rose-500">*</span></label>
                                        <input type="text" name="name" value="{{ old('name', $user->name) }}" required
                                            class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-blue-950">
                                    </div>

                                    <div class="space-y-1">
                                        <label class="font-bold text-slate-700">Email</label>
                                        <input type="email" name="email" value="{{ old('email', $user->email) }}"
                                            required
                                            class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-blue-950">
                                    </div>

                                    <div class="space-y-1">
                                        <label class="font-bold text-slate-700">Nomor Telepon</label>
                                        <input type="text" name="phone" value="0823 1234 5678"
                                            class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-blue-950">
                                    </div>

                                    <div class="space-y-1">
                                        <label class="font-bold text-slate-700">Jenis Kelamin</label>
                                        <select name="gender"
                                            class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-blue-950">
                                            <option value="Perempuan" selected>Perempuan</option>
                                            <option value="Laki-laki">Laki-laki</option>
                                        </select>
                                    </div>

                                    <div class="space-y-1">
                                        <label class="font-bold text-slate-700">Tanggal Lahir</label>
                                        <input type="date" name="birthdate" value="2003-01-12"
                                            class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-blue-950">
                                    </div>

                                    <div class="space-y-1">
                                        <label class="font-bold text-slate-700">Kewarganegaraan</label>
                                        <select name="citizenship"
                                            class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-blue-950">
                                            <option value="Indonesia" selected>Indonesia</option>
                                            <option value="Asing">Asing</option>
                                        </select>
                                    </div>
                                </div>

                                <div class="space-y-1 text-xs">
                                    <label class="font-bold text-slate-700">Nomor Identitas (KTP)<span
                                            class="text-rose-500">*</span></label>
                                    <input type="text" name="identity_number" value="3275020409980001"
                                        class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-blue-950">
                                </div>

                                <div class="space-y-1 text-xs">
                                    <label class="font-bold text-slate-700">Alamat</label>
                                    <textarea name="address" rows="3"
                                        class="w-full bg-slate-50 border border-slate-200 rounded-xl p-2.5 text-xs text-slate-800 focus:ring-2 focus:ring-blue-950">Jl. Kasepuhan No.43, Lemahwungkuk, Kota Cirebon, Jawa Barat 45114</textarea>
                                </div>

                                <div class="flex justify-end pt-2">
                                    <button type="submit"
                                        class="bg-blue-950 hover:bg-blue-900 text-white font-extrabold px-6 py-2.5 rounded-xl text-xs transition shadow-sm">
                                        Simpan Perubahan
                                    </button>
                                </div>
                            </form>
                        </div>

                        <!-- 2. Riwayat Transaksi Table Card -->
                        <div class="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-5">
                            <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                                <div>
                                    <h3 class="font-extrabold text-slate-900 text-base">Riwayat Transaksi</h3>
                                    <p class="text-xs text-slate-500 mt-0.5">Berikut adalah riwayat pemesanan tiket
                                        Anda.</p>
                                </div>
                            </div>

                            <!-- Filter Pills -->
                            <div class="flex items-center gap-2 text-xs font-bold overflow-x-auto pb-1">
                                <button class="px-4 py-1.5 bg-blue-950 text-white rounded-xl">Semua</button>
                                <button
                                    class="px-4 py-1.5 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition">Selesai</button>
                                <button
                                    class="px-4 py-1.5 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition">Menunggu</button>
                                <button
                                    class="px-4 py-1.5 bg-slate-100 text-slate-600 rounded-xl hover:bg-slate-200 transition">Dibatalkan</button>
                            </div>

                            <!-- Transactions Table -->
                            <div class="overflow-x-auto">
                                <table class="w-full text-xs text-left border-collapse">
                                    <thead>
                                        <tr
                                            class="bg-slate-50 text-slate-500 uppercase font-extrabold border-b border-slate-100">
                                            <th class="py-3 px-3">event</th>
                                            <th class="py-3 px-3">Tanggal</th>
                                            <th class="py-3 px-3">Jumlah Tiket</th>
                                            <th class="py-3 px-3">Total</th>
                                            <th class="py-3 px-3">Status</th>
                                            <th class="py-3 px-3 text-right">Aksi</th>
                                        </tr>
                                    </thead>
                                    <tbody class="divide-y divide-slate-100 font-medium">
                                        @forelse($bookings as $b)
                                        @php
                                        $statusVal = is_object($b->status) ? $b->status->value : $b->status;
                                        $firstItem = $b->items->first();
                                        $event = $firstItem?->ticket?->event;
                                        @endphp
                                        <tr class="hover:bg-slate-50/50">
                                            <td class="py-3 px-3">
                                                <div class="flex items-center gap-3">
                                                    <div
                                                        class="w-10 h-10 rounded-lg bg-slate-900 text-white shrink-0 overflow-hidden">
                                                        @if($event && $event->banner)
                                                        <img src="{{ Storage::url($event->banner) }}" alt="Banner"
                                                            class="w-full h-full object-cover">
                                                        @else
                                                        <div
                                                            class="w-full h-full flex items-center justify-center text-xs">
                                                            🎭</div>
                                                        @endif
                                                    </div>
                                                    <div>
                                                        <strong
                                                            class="font-extrabold text-slate-900 block text-xs truncate max-w-[150px]">{{
                                                            $event->title ?? 'Tiket event' }}</strong>
                                                        <span class="text-[10px] text-slate-400">20–23 Juli 2026</span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="py-3 px-3 text-slate-500 text-[11px]">
                                                {{ $b->created_at->format('d M Y') }}<br>
                                                <span class="text-[10px] text-slate-400">{{
                                                    $b->created_at->format('H:i') }} WIB</span>
                                            </td>
                                            <td class="py-3 px-3 text-slate-700 font-bold">
                                                {{ $firstItem->quantity ?? 1 }} Tiket
                                            </td>
                                            <td class="py-3 px-3 font-extrabold text-slate-900">
                                                Rp{{ number_format($b->total_amount, 0, ',', '.') }}
                                            </td>
                                            <td class="py-3 px-3">
                                                @if(in_array($statusVal, ['paid', 'payment_completed', 'confirmed']))
                                                <span
                                                    class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2.5 py-0.5 rounded-md">Selesai</span>
                                                @elseif(in_array($statusVal, ['pending', 'waiting_payment']))
                                                <span
                                                    class="bg-amber-100 text-amber-800 text-[10px] font-bold px-2.5 py-0.5 rounded-md">Menunggu</span>
                                                @else
                                                <span
                                                    class="bg-rose-100 text-rose-800 text-[10px] font-bold px-2.5 py-0.5 rounded-md">Dibatalkan</span>
                                                @endif
                                            </td>
                                            <td class="py-3 px-3 text-right">
                                                @if(in_array($statusVal, ['paid', 'payment_completed', 'confirmed']))
                                                <a href="{{ route('user.tickets.index') }}"
                                                    class="inline-block border border-slate-200 hover:bg-slate-50 text-slate-800 font-bold px-2.5 py-1 rounded-lg text-[11px] transition">
                                                    Lihat E-Ticket
                                                </a>
                                                @else
                                                <a href="{{ route('user.bookings.show', $b) }}"
                                                    class="inline-block border border-slate-200 hover:bg-slate-50 text-slate-800 font-bold px-2.5 py-1 rounded-lg text-[11px] transition">
                                                    Lihat Detail
                                                </a>
                                                @endif
                                            </td>
                                        </tr>
                                        @empty
                                        <!-- Sample Mock Rows matching screenshot if empty -->
                                        @php
                                        $mockRows = [
                                        ['title' => 'Festival Topeng Cirebon 2026', 'sub' => '20 – 23 Juli 2026', 'date'
                                        => '18 Juli 2026', 'time' => '14:32 WIB', 'qty' => '2 Tiket', 'total' =>
                                        'Rp155.000', 'status' => 'Selesai', 'st_cls' => 'bg-emerald-100
                                        text-emerald-800', 'act' => 'Lihat E-Ticket'],
                                        ['title' => 'Cirebon Night Heritage', 'sub' => '5 – 7 Agustus 2026', 'date' =>
                                        '01 Agustus 2026', 'time' => '10:15 WIB', 'qty' => '1 Tiket', 'total' =>
                                        'Rp75.000', 'status' => 'Selesai', 'st_cls' => 'bg-emerald-100
                                        text-emerald-800', 'act' => 'Lihat E-Ticket'],
                                        ['title' => 'Pameran Batik Cirebon', 'sub' => '1 – 5 October 2026', 'date' =>
                                        '25 September 2026', 'time' => '09:45 WIB', 'qty' => '2 Tiket', 'total' =>
                                        'Rp60.000', 'status' => 'Selesai', 'st_cls' => 'bg-emerald-100
                                        text-emerald-800', 'act' => 'Lihat E-Ticket'],
                                        ['title' => 'Sedekah Bumi Gunung Jati', 'sub' => '10 September 2026', 'date' =>
                                        '05 September 2026', 'time' => '11:20 WIB', 'qty' => '1 Tiket', 'total' =>
                                        'Rp0', 'status' => 'Selesai', 'st_cls' => 'bg-emerald-100 text-emerald-800',
                                        'act' => 'Lihat E-Ticket'],
                                        ['title' => 'Workshop Batik Cirebon', 'sub' => '15 November 2026', 'date' => '10
                                        November 2026', 'time' => '16:05 WIB', 'qty' => '1 Tiket', 'total' =>
                                        'Rp50.000', 'status' => 'Menunggu', 'st_cls' => 'bg-amber-100 text-amber-800',
                                        'act' => 'Lihat Detail'],
                                        ['title' => 'Ritual Adat Nadran', 'sub' => '27 December 2026', 'date' => '20
                                        Desember 2026', 'time' => '08:30 WIB', 'qty' => '2 Tiket', 'total' =>
                                        'Rp120.000', 'status' => 'Dibatalkan', 'st_cls' => 'bg-rose-100 text-rose-800',
                                        'act' => 'Lihat Detail']
                                        ];
                                        @endphp
                                        @foreach($mockRows as $mr)
                                        <tr class="hover:bg-slate-50/50">
                                            <td class="py-3 px-3">
                                                <div class="flex items-center gap-3">
                                                    <div
                                                        class="w-10 h-10 rounded-lg bg-slate-900 text-white shrink-0 overflow-hidden flex items-center justify-center font-bold text-xs">
                                                        🎭</div>
                                                    <div>
                                                        <strong class="font-extrabold text-slate-900 block text-xs">{{
                                                            $mr['title'] }}</strong>
                                                        <span class="text-[10px] text-slate-400">{{ $mr['sub'] }}</span>
                                                    </div>
                                                </div>
                                            </td>
                                            <td class="py-3 px-3 text-slate-500 text-[11px]">
                                                {{ $mr['date'] }}<br>
                                                <span class="text-[10px] text-slate-400">{{ $mr['time'] }}</span>
                                            </td>
                                            <td class="py-3 px-3 text-slate-700 font-bold">{{ $mr['qty'] }}</td>
                                            <td class="py-3 px-3 font-extrabold text-slate-900">{{ $mr['total'] }}</td>
                                            <td class="py-3 px-3">
                                                <span
                                                    class="{{ $mr['st_cls'] }} text-[10px] font-bold px-2.5 py-0.5 rounded-md">{{
                                                    $mr['status'] }}</span>
                                            </td>
                                            <td class="py-3 px-3 text-right">
                                                <button type="button"
                                                    class="border border-slate-200 hover:bg-slate-50 text-slate-800 font-bold px-2.5 py-1 rounded-lg text-[11px] transition">
                                                    {{ $mr['act'] }}
                                                </button>
                                            </td>
                                        </tr>
                                        @endforeach
                                        @endforelse
                                    </tbody>
                                </table>
                            </div>

                            <!-- Table Pagination -->
                            <div class="flex justify-center items-center gap-2 pt-2 text-xs">
                                <button
                                    class="w-7 h-7 rounded-lg border border-slate-200 flex items-center justify-center text-slate-400">&lt;</button>
                                <button
                                    class="w-7 h-7 rounded-lg bg-blue-950 text-white font-bold flex items-center justify-center">1</button>
                                <button
                                    class="w-7 h-7 rounded-lg border border-slate-200 hover:bg-slate-50 text-slate-600 font-medium flex items-center justify-center">2</button>
                                <button
                                    class="w-7 h-7 rounded-lg border border-slate-200 flex items-center justify-center text-slate-600">&gt;</button>
                            </div>
                        </div>

                        <!-- 3. Preferensi Saya Cards Row -->
                        <div class="space-y-3">
                            <h3 class="font-extrabold text-slate-900 text-sm">Preferensi Saya</h3>
                            <p class="text-xs text-slate-500 -mt-2">Kelola preferensi untuk pengalaman yang lebih
                                personal.</p>

                            <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                                <div
                                    class="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm flex items-center justify-between hover:shadow-md transition cursor-pointer">
                                    <div class="flex items-center gap-3">
                                        <div
                                            class="w-9 h-9 rounded-xl bg-rose-50 text-rose-600 flex items-center justify-center text-sm font-bold">
                                            ♥
                                        </div>
                                        <div>
                                            <h4 class="font-bold text-slate-900 text-xs">Kategori Favorit</h4>
                                            <p class="text-[10px] text-slate-400">Pilih kategori event yang Anda minati.
                                            </p>
                                        </div>
                                    </div>
                                    <span class="text-slate-400 font-bold text-xs">&rsaquo;</span>
                                </div>

                                <div
                                    class="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm flex items-center justify-between hover:shadow-md transition cursor-pointer">
                                    <div class="flex items-center gap-3">
                                        <div
                                            class="w-9 h-9 rounded-xl bg-blue-50 text-blue-600 flex items-center justify-center text-sm font-bold">
                                            🔔
                                        </div>
                                        <div>
                                            <h4 class="font-bold text-slate-900 text-xs">Notifikasi</h4>
                                            <p class="text-[10px] text-slate-400">Kelola preferensi notifikasi Anda.</p>
                                        </div>
                                    </div>
                                    <span class="text-slate-400 font-bold text-xs">&rsaquo;</span>
                                </div>

                                <div
                                    class="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm flex items-center justify-between hover:shadow-md transition cursor-pointer">
                                    <div class="flex items-center gap-3">
                                        <div
                                            class="w-9 h-9 rounded-xl bg-emerald-50 text-emerald-600 flex items-center justify-center text-sm font-bold">
                                            🔒
                                        </div>
                                        <div>
                                            <h4 class="font-bold text-slate-900 text-xs">Privasi</h4>
                                            <p class="text-[10px] text-slate-400">Atur siapa yang dapat melihat
                                                informasi Anda.</p>
                                        </div>
                                    </div>
                                    <span class="text-slate-400 font-bold text-xs">&rsaquo;</span>
                                </div>

                                <div
                                    class="bg-white rounded-2xl p-4 border border-slate-100 shadow-sm flex items-center justify-between hover:shadow-md transition cursor-pointer">
                                    <div class="flex items-center gap-3">
                                        <div
                                            class="w-9 h-9 rounded-xl bg-purple-50 text-purple-600 flex items-center justify-center text-sm font-bold">
                                            🌐
                                        </div>
                                        <div>
                                            <h4 class="font-bold text-slate-900 text-xs">Bahasa</h4>
                                            <p class="text-[10px] text-slate-400">Bahasa Indonesia</p>
                                        </div>
                                    </div>
                                    <span class="text-slate-400 font-bold text-xs">&rsaquo;</span>
                                </div>
                            </div>
                        </div>

                    </div>

                    <!-- RIGHT COLUMN (1 COL) -->
                    <div class="space-y-6">

                        <!-- 1. Ringkasan Akun Card (Dark Blue Background) -->
                        <div
                            class="bg-gradient-to-br from-blue-950 via-slate-900 to-blue-950 text-white rounded-3xl p-6 shadow-md space-y-6 relative overflow-hidden">
                            <div class="flex items-center gap-4">
                                <div
                                    class="w-14 h-14 rounded-full bg-amber-500 text-slate-950 font-black text-xl flex items-center justify-center uppercase ring-4 ring-white/10 shadow-md">
                                    {{ substr($user->name, 0, 2) }}
                                </div>
                                <div>
                                    <h3 class="font-extrabold text-sm text-white">{{ $user->name }}</h3>
                                    <span
                                        class="inline-block mt-1 bg-amber-500/20 text-amber-400 border border-amber-500/40 text-[9px] font-extrabold px-2.5 py-0.5 rounded-md uppercase">
                                        Member
                                    </span>
                                </div>
                            </div>

                            <div class="grid grid-cols-3 gap-2 text-center border-t border-slate-800/80 pt-4 text-xs">
                                <div>
                                    <span class="font-black text-base text-white block">3</span>
                                    <span class="text-[10px] text-slate-400">Pesanan</span>
                                </div>
                                <div>
                                    <span class="font-black text-base text-white block">2</span>
                                    <span class="text-[10px] text-slate-400">E-Ticket</span>
                                </div>
                                <div>
                                    <span class="font-black text-base text-white block">0</span>
                                    <span class="text-[10px] text-slate-400">Wishlist</span>
                                </div>
                            </div>

                            <div class="grid grid-cols-2 gap-2 text-center border-t border-slate-800/80 pt-4 text-xs">
                                <div>
                                    <span class="font-black text-base text-amber-400 block">1.250</span>
                                    <span class="text-[10px] text-slate-400">Poin Cireva</span>
                                </div>
                                <div>
                                    <span class="font-black text-base text-emerald-400 block">Aktif</span>
                                    <span class="text-[10px] text-slate-400">Status Akun</span>
                                </div>
                            </div>
                        </div>

                        <!-- 2. Keamanan Akun Card -->
                        <div class="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
                            <div class="border-b border-slate-100 pb-3">
                                <h3 class="font-extrabold text-slate-900 text-sm">Keamanan Akun</h3>
                                <p class="text-[11px] text-slate-500 mt-0.5">Jaga keamanan akun Anda.</p>
                            </div>

                            <div class="space-y-3.5 text-xs">
                                <div
                                    class="flex items-center justify-between hover:bg-slate-50 p-2 rounded-xl transition cursor-pointer">
                                    <div class="flex items-center gap-3">
                                        <span class="text-slate-400">🔑</span>
                                        <div>
                                            <h4 class="font-bold text-slate-900">Ubah Password</h4>
                                            <p class="text-[10px] text-slate-400">Ganti password akun Anda secara
                                                berkala.</p>
                                        </div>
                                    </div>
                                    <span class="text-slate-400 font-bold">&rsaquo;</span>
                                </div>

                                <div class="flex items-center justify-between p-2 rounded-xl">
                                    <div class="flex items-center gap-3">
                                        <span class="text-slate-400">🛡️</span>
                                        <div>
                                            <h4 class="font-bold text-slate-900">Verifikasi Email</h4>
                                            <p class="text-[10px] text-slate-400">Email Anda telah terverifikasi.</p>
                                        </div>
                                    </div>
                                    <span class="text-emerald-500 font-bold">✓</span>
                                </div>

                                <div class="flex items-center justify-between p-2 rounded-xl">
                                    <div class="flex items-center gap-3">
                                        <span class="text-slate-400">📱</span>
                                        <div>
                                            <h4 class="font-bold text-slate-900">Verifikasi Nomor</h4>
                                            <p class="text-[10px] text-slate-400">Nomor Anda telah terverifikasi.</p>
                                        </div>
                                    </div>
                                    <span class="text-emerald-500 font-bold">✓</span>
                                </div>
                            </div>
                        </div>

                        <!-- 3. Metode Pembayaran Card -->
                        <div class="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
                            <div class="border-b border-slate-100 pb-3">
                                <h3 class="font-extrabold text-slate-900 text-sm">Metode Pembayaran</h3>
                                <p class="text-[11px] text-slate-500 mt-0.5">Kelola metode pembayaran Anda.</p>
                            </div>

                            <div
                                class="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 flex items-center justify-between">
                                <div class="flex items-center gap-2">
                                    <span class="font-black text-xs text-slate-900">QRIS</span>
                                </div>
                                <span
                                    class="bg-emerald-100 text-emerald-800 text-[10px] font-bold px-2 py-0.5 rounded-md">Aktif</span>
                            </div>

                            <button type="button"
                                class="w-full py-2.5 border border-slate-300 hover:bg-slate-50 rounded-xl text-xs font-bold text-slate-700 transition">
                                + Tambah Metode Pembayaran
                            </button>
                        </div>

                        <!-- 4. Butuh Bantuan? Card -->
                        <div class="bg-white rounded-3xl p-6 border border-slate-100 shadow-sm space-y-4">
                            <div class="border-b border-slate-100 pb-3">
                                <h3 class="font-extrabold text-slate-900 text-sm">Butuh Bantuan?</h3>
                                <p class="text-[11px] text-slate-500 mt-0.5">Hubungi kami melalui kanal berikut.</p>
                            </div>

                            <div class="space-y-3 text-xs">
                                <div class="flex items-center gap-3">
                                    <div
                                        class="w-8 h-8 rounded-full bg-emerald-100 text-emerald-600 flex items-center justify-center shrink-0">
                                        💬</div>
                                    <div>
                                        <strong class="font-extrabold text-slate-900 block text-xs">0823 1234
                                            5678</strong>
                                        <span class="text-[10px] text-slate-400">WhatsApp</span>
                                    </div>
                                </div>

                                <div class="flex items-center gap-3">
                                    <div
                                        class="w-8 h-8 rounded-full bg-blue-100 text-blue-600 flex items-center justify-center shrink-0">
                                        ✉️</div>
                                    <div>
                                        <strong
                                            class="font-extrabold text-slate-900 block text-xs">support@cireva.id</strong>
                                        <span class="text-[10px] text-slate-400">Email</span>
                                    </div>
                                </div>

                                <div class="flex items-center gap-3">
                                    <div
                                        class="w-8 h-8 rounded-full bg-amber-100 text-amber-600 flex items-center justify-center shrink-0">
                                        ⏰</div>
                                    <div>
                                        <strong class="font-extrabold text-slate-900 block text-xs">Jam Layanan</strong>
                                        <span class="text-[10px] text-slate-400">Setiap hari 08.00 – 20.00 WIB</span>
                                    </div>
                                </div>
                            </div>
                        </div>

                    </div>
                </div>

            </main>
        </div>
    </div>
</x-app-layout>