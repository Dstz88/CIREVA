@auth
<x-app-layout>
    <div class="flex min-h-screen bg-slate-50" x-data="{ 
        selectedevent: {
            title: 'Festival Topeng Cirebon',
            category: 'Festival',
            description: 'Seni tari topeng klasik dari Keraton Kasepuhan yang menggambarkan watak manusia.',
            time: '12 Oktober 2024, 19:00 - Selesai',
            location: 'Alun-Alun Sangkala Buana, Cirebon',
            organizer: 'Dinas Kebudayaan Cirebon',
            price: 'Gratis / Open Donation',
            seats: '42/150',
            image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=600'
        },
        showDrawer: true
    }">
        <!-- Sidebar User -->
        <x-user-sidebar />

        <!-- Main Content Wrapper -->
        <div class="flex-1 flex flex-col min-w-0">
            <!-- Top Navbar Search & Profile -->
            <header
                class="bg-white border-b border-slate-100 py-4 px-8 flex items-center justify-between sticky top-0 z-10 shadow-sm">
                <div class="relative w-full max-w-md">
                    <input type="text" placeholder="Cari event, tempat, atau kategori..."
                        class="w-full bg-slate-50 text-xs border-0 rounded-full py-2.5 pl-5 pr-10 focus:ring-2 focus:ring-blue-900 focus:bg-white transition placeholder-slate-400">
                    <svg class="w-4 h-4 text-slate-400 absolute right-4 top-3" fill="none" stroke="currentColor"
                        viewBox="0 0 24 24">
                        <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                            d="M21 21l-6-6m2-5a7 7 0 11-14 0 7 7 0 0114 0z" />
                    </svg>
                </div>

                <div class="flex items-center gap-4">
                    <a href="{{ route('notifications.index') }}"
                        class="relative p-2 text-slate-500 hover:text-slate-700 rounded-full hover:bg-slate-100 transition">
                        <svg class="w-5 h-5" fill="none" stroke="currentColor" viewBox="0 0 24 24">
                            <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                d="M15 17h5l-1.405-1.405A2.032 2.032 0 0118 14.158V11a6.002 6.002 0 00-4-5.659V5a2 2 0 10-4 0v.341C7.67 6.165 6 8.388 6 11v3.159c0 .538-.214 1.055-.595 1.436L4 17h5m6 0v1a3 3 0 11-6 0v-1m6 0H9" />
                        </svg>
                        <span
                            class="absolute top-1 right-1 bg-rose-500 text-white text-[10px] font-bold w-4 h-4 flex items-center justify-center rounded-full">2</span>
                    </a>

                    <div class="flex items-center gap-3 pl-2 border-l border-slate-100">
                        <span class="text-xs font-semibold text-slate-700">Halo, <span
                                class="font-bold text-slate-900">{{ Auth::user()->name }}</span>!</span>
                        <div
                            class="w-9 h-9 rounded-full bg-blue-900 text-white flex items-center justify-center font-bold text-xs uppercase shadow-sm">
                            {{ substr(Auth::user()->name, 0, 2) }}
                        </div>
                    </div>
                </div>
            </header>

            <!-- Main Body Content -->
            <main class="p-8 flex-1 space-y-6">
                <!-- Page Title -->
                <div>
                    <h1 class="text-2xl font-black text-slate-900 tracking-tight">Kalender Budaya</h1>
                    <p class="text-xs text-slate-500 mt-1">Jadwal lengkap pagelaran seni dan festival budaya Kota
                        Cirebon.</p>
                </div>

                <div class="flex flex-col lg:flex-row gap-6">



                    <!-- 2. Middle Calendar Grid Section -->
                    <div class="flex-1 space-y-6">

                        <!-- Top Stat Cards -->
                        <div class="grid grid-cols-2 sm:grid-cols-4 gap-4">
                            <div
                                class="bg-white rounded-2xl p-4 text-center border border-slate-100 shadow-sm space-y-1">
                                <p class="text-2xl font-extrabold text-amber-700">12</p>
                                <p class="text-xs font-semibold text-slate-500">Bulan Ini</p>
                            </div>
                            <div
                                class="bg-white rounded-2xl p-4 text-center border border-slate-100 shadow-sm space-y-1">
                                <p class="text-2xl font-extrabold text-amber-700">2</p>
                                <p class="text-xs font-semibold text-slate-500">Hari Ini</p>
                            </div>
                            <div
                                class="bg-white rounded-2xl p-4 text-center border border-slate-100 shadow-sm space-y-1">
                                <p class="text-2xl font-extrabold text-amber-700">5</p>
                                <p class="text-xs font-semibold text-slate-500">Gratis</p>
                            </div>
                            <div
                                class="bg-white rounded-2xl p-4 text-center border border-slate-100 shadow-sm space-y-1">
                                <p class="text-2xl font-extrabold text-amber-700">7</p>
                                <p class="text-xs font-semibold text-slate-500">Berbayar</p>
                            </div>
                        </div>

                        <!-- Main Calendar Box -->
                        <div class="bg-white rounded-3xl p-6 shadow-sm border border-slate-100 space-y-4">
                            <div
                                class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-slate-100 pb-4">
                                <div class="flex items-center gap-3">
                                    <h3 class="text-xl font-extrabold text-slate-900">Oktober 2024</h3>
                                    <div
                                        class="flex items-center border border-slate-200 rounded-lg overflow-hidden text-xs">
                                        <button class="px-2 py-1 hover:bg-slate-100 text-slate-600">&lt;</button>
                                        <button class="px-3 py-1 font-semibold text-slate-700 bg-slate-50">Hari
                                            Ini</button>
                                        <button class="px-2 py-1 hover:bg-slate-100 text-slate-600">&gt;</button>
                                    </div>
                                </div>

                                <div class="flex items-center gap-2">
                                    <select
                                        class="bg-slate-100 border-none rounded-xl text-xs font-semibold text-slate-700 py-1.5 px-3">
                                        <option>Oktober</option>
                                        <option>November</option>
                                        <option>Desember</option>
                                    </select>
                                    <select
                                        class="bg-slate-100 border-none rounded-xl text-xs font-semibold text-slate-700 py-1.5 px-3">
                                        <option>2024</option>
                                        <option>2025</option>
                                        <option>2026</option>
                                    </select>
                                </div>
                            </div>

                            <div class="overflow-x-auto">
                                <table
                                    class="w-full border-collapse border border-indigo-100 rounded-xl overflow-hidden min-w-[600px]">
                                    <thead>
                                        <tr class="bg-[#8198D6] text-white text-xs font-bold text-center">
                                            <th class="py-2 border border-indigo-200/50 w-[14%]">Sen</th>
                                            <th class="py-2 border border-indigo-200/50 w-[14%]">Sel</th>
                                            <th class="py-2 border border-indigo-200/50 w-[14%]">Rab</th>
                                            <th class="py-2 border border-indigo-200/50 w-[14%]">Kam</th>
                                            <th class="py-2 border border-indigo-200/50 w-[14%]">Jum</th>
                                            <th class="py-2 border border-indigo-200/50 w-[14%]">Sab</th>
                                            <th class="py-2 border border-indigo-200/50 w-[14%]">Min</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-xs text-slate-700">
                                        <tr class="h-20 align-top">
                                            <td class="p-1.5 border border-indigo-100 text-slate-400">30</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">1</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">2</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">
                                                <span>3</span>
                                                <div
                                                    class="mt-1 bg-cyan-100 text-cyan-800 text-[9px] font-semibold px-1.5 py-0.5 rounded truncate">
                                                    Musik Pantura</div>
                                            </td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">4</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">
                                                <span>5</span>
                                                <div
                                                    class="mt-1 bg-rose-100 text-rose-800 text-[9px] font-semibold px-1.5 py-0.5 rounded truncate">
                                                    Sedekah Bumi</div>
                                            </td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">6</td>
                                        </tr>

                                        <tr class="h-20 align-top">
                                            <td class="p-1.5 border border-indigo-100 font-bold">7</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">8</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">9</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">
                                                <span>10</span>
                                                <div
                                                    class="mt-1 bg-emerald-100 text-emerald-800 text-[9px] font-semibold px-1.5 py-0.5 rounded truncate">
                                                    Batik Workshop</div>
                                            </td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">11</td>
                                            <td class="p-1.5 border-2 border-indigo-500 bg-indigo-50/50 font-bold cursor-pointer"
                                                @click="showDrawer = true">
                                                <span class="text-indigo-900 font-extrabold">12</span>
                                                <div class="mt-1 space-y-1">
                                                    <div
                                                        class="bg-amber-200 text-amber-900 text-[9px] font-bold px-1.5 py-0.5 rounded truncate">
                                                        Festival Topeng</div>
                                                    <div
                                                        class="bg-blue-200 text-blue-900 text-[9px] font-bold px-1.5 py-0.5 rounded truncate">
                                                        Performance Tari</div>
                                                </div>
                                            </td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">13</td>
                                        </tr>

                                        <tr class="h-20 align-top">
                                            <td class="p-1.5 border border-indigo-100 font-bold">14</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">15</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">
                                                <span>16</span>
                                                <div
                                                    class="mt-1 bg-purple-100 text-purple-800 text-[9px] font-semibold px-1.5 py-0.5 rounded truncate">
                                                    Gallery Talk</div>
                                            </td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">17</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">18</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">19</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">20</td>
                                        </tr>

                                        <tr class="h-20 align-top">
                                            <td class="p-1.5 border border-indigo-100 font-bold">21</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">22</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">23</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">24</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">25</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">
                                                <span>26</span>
                                                <div
                                                    class="mt-1 bg-amber-100 text-amber-900 text-[9px] font-semibold px-1.5 py-0.5 rounded truncate">
                                                    Pasar Seni</div>
                                            </td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">27</td>
                                        </tr>

                                        <tr class="h-20 align-top">
                                            <td class="p-1.5 border border-indigo-100 font-bold">28</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">29</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">30</td>
                                            <td class="p-1.5 border border-indigo-100 font-bold">31</td>
                                            <td class="p-1.5 border border-indigo-100 text-slate-400">1</td>
                                            <td class="p-1.5 border border-indigo-100 text-slate-400">2</td>
                                            <td class="p-1.5 border border-indigo-100 text-slate-400">3</td>
                                        </tr>
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                    <!-- 3. Right Side Panel / Drawer (Detail event) -->
                    <div x-show="showDrawer" x-transition
                        class="w-full lg:w-80 shrink-0 bg-white rounded-3xl p-6 shadow-md border border-slate-100 space-y-5 self-start">
                        <div class="flex items-center justify-between border-b border-slate-100 pb-3">
                            <h3 class="text-base font-extrabold text-slate-900">Detail event</h3>
                            <button @click="showDrawer = false"
                                class="text-slate-400 hover:text-slate-600 font-bold text-base">&times;</button>
                        </div>

                        <div class="h-44 rounded-2xl overflow-hidden relative shadow-sm bg-slate-900">
                            <img :src="selectedevent.image" :alt="selectedevent.title"
                                class="w-full h-full object-cover">
                            <div class="absolute top-3 left-3">
                                <span
                                    class="bg-amber-600 text-white text-[10px] font-bold px-3 py-1 rounded-full shadow-sm"
                                    x-text="selectedevent.category"></span>
                            </div>
                        </div>

                        <div class="space-y-2">
                            <h4 class="text-lg font-extrabold text-slate-900 leading-snug" x-text="selectedevent.title">
                            </h4>
                            <p class="text-xs text-slate-500 leading-relaxed" x-text="selectedevent.description"></p>
                        </div>

                        <div class="space-y-3 pt-3 border-t border-slate-100 text-xs">
                            <div class="flex items-start gap-2.5">
                                <svg class="w-4 h-4 text-amber-600 shrink-0 mt-0.5" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M8 7V3m8 4V3m-9 8h10M5 21h14a2 2 0 002-2V7a2 2 0 00-2-2H5a2 2 0 00-2 2v12a2 2 0 002 2z" />
                                </svg>
                                <div>
                                    <p class="font-bold text-slate-400 text-[10px] uppercase">Waktu</p>
                                    <p class="font-bold text-slate-800" x-text="selectedevent.time"></p>
                                </div>
                            </div>

                            <div class="flex items-start gap-2.5">
                                <svg class="w-4 h-4 text-amber-600 shrink-0 mt-0.5" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M17.657 16.657L13.414 20.9a1.998 1.998 0 01-2.827 0l-4.244-4.243a8 8 0 1111.314 0z" />
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M15 11a3 3 0 11-6 0 3 3 0 016 0z" />
                                </svg>
                                <div>
                                    <p class="font-bold text-slate-400 text-[10px] uppercase">Lokasi</p>
                                    <p class="font-bold text-slate-800" x-text="selectedevent.location"></p>
                                </div>
                            </div>

                            <div class="flex items-start gap-2.5">
                                <svg class="w-4 h-4 text-amber-600 shrink-0 mt-0.5" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M16 7a4 4 0 11-8 0 4 4 0 018 0zM12 14a7 7 0 00-7 7h14a7 7 0 00-7-7z" />
                                </svg>
                                <div>
                                    <p class="font-bold text-slate-400 text-[10px] uppercase">Penyelenggara</p>
                                    <p class="font-bold text-slate-800" x-text="selectedevent.organizer"></p>
                                </div>
                            </div>

                            <div class="flex items-start gap-2.5">
                                <svg class="w-4 h-4 text-amber-600 shrink-0 mt-0.5" fill="none" stroke="currentColor"
                                    viewBox="0 0 24 24">
                                    <path stroke-linecap="round" stroke-linejoin="round" stroke-width="2"
                                        d="M15 5v2m0 4v2m0 4v2M5 5a2 2 0 00-2 2v3a2 2 0 002 2 2 2 0 010 4 2 2 0 00-2 2v3a2 2 0 002 2h14a2 2 0 002-2v-3a2 2 0 00-2-2 2 2 0 010-4 2 2 0 002-2V7a2 2 0 00-2-2H5z" />
                                </svg>
                                <div>
                                    <p class="font-bold text-slate-400 text-[10px] uppercase">Harga</p>
                                    <p class="font-extrabold text-amber-700" x-text="selectedevent.price"></p>
                                </div>
                            </div>
                        </div>

                        <div class="pt-2">
                            <a href="{{ route('events.index') }}"
                                class="w-full bg-blue-950 hover:bg-blue-900 text-white font-bold py-3 rounded-xl text-xs flex items-center justify-center transition shadow-md">
                                Lihat Detail Lengkap
                            </a>
                        </div>
                    </div>

                </div>
            </main>
        </div>
    </div>
</x-app-layout>
@else
<!-- GUEST PUBLIC LAYOUT FOR CALENDAR -->
<x-public-layout>
    <div class="py-8 bg-slate-50/50 min-h-screen" x-data="{ 
        selectedevent: {
            title: 'Festival Topeng Cirebon',
            category: 'Festival',
            description: 'Seni tari topeng klasik dari Keraton Kasepuhan yang menggambarkan watak manusia.',
            time: '12 Oktober 2024, 19:00 - Selesai',
            location: 'Alun-Alun Sangkala Buana, Cirebon',
            organizer: 'Dinas Kebudayaan Cirebon',
            price: 'Gratis / Open Donation',
            seats: '42/150',
            image: 'https://images.unsplash.com/photo-1514525253161-7a46d19cd819?q=80&w=600'
        },
        showDrawer: true
    }">
        @php
        $cMonth = isset($currentMonth) ? $currentMonth : now()->startOfMonth();
        $startOfMonth = $cMonth->copy()->startOfMonth();
        $endOfMonth = $cMonth->copy()->endOfMonth();
        $daysInMonth = $cMonth->daysInMonth;

        // ISO-8601 day of week (1 for Monday, 7 for Sunday)
        $startDayOfWeek = $startOfMonth->isoWeekday();
        $prevMonthEnd = $startOfMonth->copy()->subDay();
        $prevMonthDaysToShow = $startDayOfWeek - 1;
        $startPrevDate = $prevMonthEnd->day - $prevMonthDaysToShow + 1;

        $prevMonthUrl = route('calendar.index', array_merge(request()->query(), ['month' =>
        $cMonth->copy()->subMonth()->format('Y-m')]));
        $nextMonthUrl = route('calendar.index', array_merge(request()->query(), ['month' =>
        $cMonth->copy()->addMonth()->format('Y-m')]));
        @endphp

        <div class="py-10 bg-slate-50 min-h-[calc(100vh-5rem)]">
            <div class="max-w-[1400px] mx-auto px-4 sm:px-6 lg:px-8">
                <div class="flex flex-col lg:flex-row gap-6">



                    <!-- Middle Calendar Grid -->
                    <div class="flex-1 space-y-6">
                        <div class="bg-white rounded-3xl p-6 shadow-sm border border-gray-100 space-y-4">
                            <!-- Month Navigation Header -->
                            <div
                                class="flex flex-col sm:flex-row sm:items-center justify-between gap-4 border-b border-gray-100 pb-4">
                                <h3 class="text-xl font-extrabold text-slate-900">
                                    {{ $cMonth->translatedFormat('F Y') }}
                                </h3>
                                <div class="flex items-center gap-2">
                                    <a href="{{ $prevMonthUrl }}"
                                        class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition text-xs font-bold flex items-center gap-1">
                                        &larr; Bulan Sebelumnya
                                    </a>
                                    <a href="{{ route('calendar.index') }}"
                                        class="px-3 py-1.5 bg-amber-500 hover:bg-amber-600 text-slate-950 rounded-xl transition text-xs font-bold">
                                        Bulan Ini
                                    </a>
                                    <a href="{{ $nextMonthUrl }}"
                                        class="px-3 py-1.5 bg-slate-100 hover:bg-slate-200 text-slate-700 rounded-xl transition text-xs font-bold flex items-center gap-1">
                                        Bulan Selanjutnya &rarr;
                                    </a>
                                </div>
                            </div>

                            <!-- Calendar Grid Table (Original Style Guide) -->
                            <div class="overflow-x-auto">
                                <table
                                    class="w-full border-collapse border border-indigo-100 rounded-xl overflow-hidden min-w-[700px]">
                                    <thead>
                                        <tr class="bg-[#8198D6] text-white text-xs font-bold text-center">
                                            <th class="py-2.5 border border-indigo-200/50 w-[14.28%]">Sen</th>
                                            <th class="py-2.5 border border-indigo-200/50 w-[14.28%]">Sel</th>
                                            <th class="py-2.5 border border-indigo-200/50 w-[14.28%]">Rab</th>
                                            <th class="py-2.5 border border-indigo-200/50 w-[14.28%]">Kam</th>
                                            <th class="py-2.5 border border-indigo-200/50 w-[14.28%]">Jum</th>
                                            <th class="py-2.5 border border-indigo-200/50 w-[14.28%]">Sab</th>
                                            <th class="py-2.5 border border-indigo-200/50 w-[14.28%]">Min</th>
                                        </tr>
                                    </thead>
                                    <tbody class="text-xs text-slate-700">
                                        @php
                                        $currentDayCounter = 1;
                                        $nextMonthCounter = 1;
                                        $totalCells = 35; // 5 weeks x 7 days
                                        if (($prevMonthDaysToShow + $daysInMonth) > 35) {
                                        $totalCells = 42;
                                        }
                                        @endphp

                                        @for($cell = 1; $cell <= $totalCells; $cell++) @if(($cell - 1) % 7==0) <tr
                                            class="h-24 align-top">
                                            @endif

                                            @if($cell <= $prevMonthDaysToShow) <!-- Previous Month Days -->
                                                <td class="p-2 border border-indigo-100 text-slate-400 bg-slate-50/50">
                                                    <span>{{ $startPrevDate + $cell - 1 }}</span>
                                                </td>
                                                @elseif($currentDayCounter <= $daysInMonth) <!-- Current Month Days -->
                                                    @php
                                                    $dateString = $cMonth->format('Y-m-') . sprintf('%02d',
                                                    $currentDayCounter);
                                                    $isToday = $dateString === now()->format('Y-m-d');

                                                    // Find events for this date
                                                    $dayEvents = collect();
                                                    if (isset($events)) {
                                                    foreach($events as $ev) {
                                                    foreach($ev->schedules as $sched) {
                                                    if ($sched->start_datetime &&
                                                    \Carbon\Carbon::parse($sched->start_datetime)->format('Y-m-d') ===
                                                    $dateString) {
                                                    $dayEvents->push($ev);
                                                    break;
                                                    }
                                                    }
                                                    }
                                                    }
                                                    @endphp

                                                    <td
                                                        class="p-2 border border-indigo-100 font-bold {{ $isToday ? 'bg-amber-50/60 ring-2 ring-amber-400 inset-0' : 'bg-white' }}">
                                                        <div class="flex items-center justify-between">
                                                            <span
                                                                class="{{ $isToday ? 'text-amber-700 font-black' : 'text-slate-800' }}">{{
                                                                $currentDayCounter }}</span>
                                                            @if($isToday)
                                                            <span
                                                                class="text-[9px] bg-amber-500 text-white font-extrabold px-1 rounded">Hari
                                                                ini</span>
                                                            @endif
                                                        </div>

                                                        <div class="mt-1.5 space-y-1">
                                                            @foreach($dayEvents->take(2) as $dEv)
                                                            <a href="{{ route('events.show', $dEv) }}"
                                                                title="{{ $dEv->title }}"
                                                                class="block bg-amber-100 hover:bg-amber-200 text-amber-900 text-[10px] font-bold px-1.5 py-1 rounded truncate transition">
                                                                {{ $dEv->title }}
                                                            </a>
                                                            @endforeach
                                                            @if($dayEvents->count() > 2)
                                                            <span
                                                                class="text-[9px] text-slate-500 font-semibold block">+{{
                                                                $dayEvents->count() - 2 }} event lagi</span>
                                                            @endif
                                                        </div>
                                                    </td>
                                                    @php $currentDayCounter++; @endphp
                                                    @else
                                                    <!-- Next Month Days -->
                                                    <td
                                                        class="p-2 border border-indigo-100 text-slate-400 bg-slate-50/50">
                                                        <span>{{ $nextMonthCounter++ }}</span>
                                                    </td>
                                                    @endif

                                                    @if($cell % 7 == 0)
                                                    </tr>
                                                    @endif
                                                    @endfor
                                    </tbody>
                                </table>
                            </div>
                        </div>
                    </div>

                </div>
            </div>
        </div>
</x-public-layout>
@endauth