<?php

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;
use Illuminate\Support\Facades\Auth;

class CheckRole
{
    /**
     * Handle an incoming request.
     *
     * @param  \Closure(\Illuminate\Http\Request): (\Symfony\Component\HttpFoundation\Response)  $next
     */
    public function handle(Request $request, Closure $next, string $role): Response
    {
        if (!Auth::check()) {
            return redirect('/login');
        }

        $user = Auth::user();
        $userRole = is_object($user->role) ? strtolower($user->role->name ?? '') : strtolower((string)$user->role);
        if (!$userRole || $userRole !== strtolower($role)) {
            abort(403, 'Unauthorized access.');
        }

        return $next($request);
    }
}
