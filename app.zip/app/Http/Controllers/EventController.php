<?php

namespace App\Http\Controllers;

use App\Services\eventService;
use App\Models\event;
use App\Http\Requests\StoreeventRequest;
use App\Http\Requests\UpdateeventRequest;
use Illuminate\Http\Request;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\RedirectResponse;
use Illuminate\View\View;
use Illuminate\Support\Facades\Auth;
use Illuminate\Foundation\Auth\Access\AuthorizesRequests;
use App\Repositories\Contracts\eventRepositoryInterface;
use Exception;

class eventController extends Controller
{
    use AuthorizesRequests;

    protected eventService $eventService;
    protected eventRepositoryInterface $eventRepository;

    public function __construct(eventService $eventService, eventRepositoryInterface $eventRepository)
    {
        $this->eventService = $eventService;
        $this->eventRepository = $eventRepository;
    }

    /**
     * Display a listing of public events.
     */
    public function index(Request $request)
    {
        $filters = $request->only(['search', 'category', 'category_id', 'location', 'location_id', 'date', 'status', 'sort']);
        $events = $this->eventRepository->filter($filters, 10);

        if ($request->wantsJson()) {
            return response()->json([
                'message' => 'event list endpoint.',
                'data' => $events
            ]);
        }

        $user = Auth::user();
        $locations = \App\Models\eventLocation::orderBy('name')->get();
        $categories = \App\Models\eventCategory::orderBy('name')->get();

        $roleName = $user ? (is_object($user->role) ? strtolower($user->role->name ?? '') : strtolower((string)$user->role)) : '';

        if ($roleName === 'organizer') {
            $organizerId = $user->organizerProfile->id ?? 0;
            $events = $this->eventRepository->filter(['organizer_profile_id' => $organizerId], 10);
            return view('organizer.events.index', compact('events'));
        } elseif ($roleName === 'admin') {
            return view('admin.events.index', compact('events'));
        } elseif ($roleName === 'user') {
            return view('user.events.index', compact('events', 'locations', 'categories'));
        }

        return view('user.events.index', compact('events', 'locations', 'categories'));
    }

    /**
     * Show the form for creating a new resource.
     */
    public function create(): View
    {
        return view('organizer.events.create');
    }

    /**
     * Display the specified event.
     */
    public function show(event $event)
    {
        $this->authorize('view', $event);

        if (request()->wantsJson()) {
            return response()->json([
                'data' => $event
            ]);
        }

        $user = Auth::user();
        if ($user && strtolower($user->role->name) === 'user') {
            return view('user.events.show', compact('event'));
        }

        return view('user.events.show', compact('event'));
    }

    /**
     * Show the form for editing the specified resource.
     */
    public function edit(event $event): View
    {
        $this->authorize('update', $event);
        return view('organizer.events.edit', compact('event'));
    }

    /**
     * Store a newly created event draft in storage.
     */
    public function store(StoreeventRequest $request)
    {
        $organizerProfile = Auth::user()->organizerProfile;

        if (!$organizerProfile) {
            if ($request->wantsJson()) {
                return response()->json(['message' => 'Organizer profile required.'], 403);
            }
            return back()->withErrors(['error' => 'Organizer profile required.']);
        }

        try {
            $data = $request->validated();

            if ($request->hasFile('image')) {
                $path = $request->file('image')->store('events/banners', 'public');
                $data['banner'] = $path;
            } elseif ($request->hasFile('banner')) {
                $path = $request->file('banner')->store('events/banners', 'public');
                $data['banner'] = $path;
            } else {
                $data['banner'] = 'events/banners/default.jpg';
            }

            $event = $this->eventService->createDraft($organizerProfile->id, $data);

            // Auto submit to admin verification
            $event->update([
                'status' => \App\Enums\eventStatus::Submitted->value ?? 'submitted',
            ]);

            // Create default schedule if start_date provided
            if ($request->filled('start_date')) {
                \App\Models\eventSchedule::create([
                    'event_id' => $event->id,
                    'start_datetime' => $request->start_date,
                    'end_datetime' => $request->end_date ?? $request->start_date,
                    'timezone' => 'Asia/Jakarta',
                    'status' => \App\Enums\ScheduleStatus::Published->value ?? 'published',
                ]);
            }

            // Create default ticket if capacity provided
            if ($request->filled('capacity')) {
                $isPaid = $request->input('is_paid', '1') == '1';
                $ticketPrice = $isPaid ? (float) $request->input('price', 0) : 0;
                $ticketName = $isPaid ? 'Tiket Masuk (Berbayar)' : 'Tiket Masuk (Gratis)';

                \App\Models\Ticket::create([
                    'event_id' => $event->id,
                    'name' => $ticketName,
                    'description' => $isPaid ? 'Tiket berbayar ' . $event->title : 'Tiket masuk gratis ' . $event->title,
                    'price' => $ticketPrice,
                    'quota' => (int) $request->capacity,
                    'sold' => 0,
                    'status' => \App\Enums\TicketStatus::Active->value ?? 'active',
                ]);
            }

            // Create in-app Notification for organizer
            \App\Models\Notification::create([
                'user_id' => Auth::id(),
                'title' => 'Pengajuan event Berhasil!',
                'message' => 'event "' . $event->title . '" telah berhasil diunggah dan diajukan ke Admin untuk proses verifikasi publikasi.',
                'is_read' => false,
            ]);

            if ($request->wantsJson()) {
                return response()->json([
                    'message' => 'event submitted for review successfully.',
                    'data' => $event
                ], 201);
            }
            return redirect()->route('organizer.events.index')
                ->with('success', 'event "' . $event->title . '" berhasil diajukan ke Admin untuk verifikasi & publikasi!');
        } catch (Exception $e) {
            if ($request->wantsJson()) {
                return response()->json(['message' => $e->getMessage()], 400);
            }
            return back()->withErrors(['error' => $e->getMessage()])->withInput();
        }
    }

    /**
     * Update the specified event in storage.
     */
    public function update(UpdateeventRequest $request, event $event)
    {
        try {
            $this->eventService->updateevent($event->id, $request->validated());

            if ($request->wantsJson()) {
                return response()->json([
                    'message' => 'event updated successfully.'
                ]);
            }
            return redirect()->route('organizer.events.index')->with('success', 'event updated successfully.');
        } catch (Exception $e) {
            if ($request->wantsJson()) {
                return response()->json(['message' => $e->getMessage()], 400);
            }
            return back()->withErrors(['error' => $e->getMessage()])->withInput();
        }
    }

    /**
     * Remove the specified event from storage.
     */
    public function destroy(event $event, Request $request)
    {
        $this->authorize('delete', $event);

        try {
            $event->delete();

            if ($request->wantsJson()) {
                return response()->json([
                    'message' => 'event deleted successfully.'
                ]);
            }
            return redirect()->route('organizer.events.index')->with('info', 'event "' . $event->title . '" telah berhasil dihapus.');
        } catch (Exception $e) {
            if ($request->wantsJson()) {
                return response()->json(['message' => $e->getMessage()], 400);
            }
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    // ==========================================
    // State Transitions
    // ==========================================

    /**
     * Submit an event for review.
     */
    public function submit(event $event, Request $request)
    {
        $this->authorize('submit', $event);

        try {
            $this->eventService->submit($event->id);

            if ($request->wantsJson()) {
                return response()->json([
                    'message' => 'event submitted for review successfully.'
                ]);
            }
            return back()->with('success', 'event submitted for review successfully.');
        } catch (Exception $e) {
            if ($request->wantsJson()) {
                return response()->json(['message' => $e->getMessage()], 400);
            }
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    /**
     * Publish an event.
     */
    public function publish(event $event, Request $request)
    {
        $this->authorize('publish', $event);

        try {
            $this->eventService->publish($event->id, Auth::id());

            if ($request->wantsJson()) {
                return response()->json([
                    'message' => 'event published successfully.'
                ]);
            }
            return back()->with('success', 'event published successfully.');
        } catch (Exception $e) {
            if ($request->wantsJson()) {
                return response()->json(['message' => $e->getMessage()], 400);
            }
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    /**
     * Admin: Approve an event (moves Submitted -> UnderReview -> Approved).
     */
    public function approve(event $event, Request $request)
    {
        $this->authorize('adminApprove', $event);

        try {
            // Move to UnderReview if still Submitted
            if ($event->status === \App\Enums\eventStatus::Submitted) {
                $this->eventService->review($event->id);
                $event->refresh();
            }
            $this->eventService->approve($event->id, Auth::id());

            if ($request->wantsJson()) {
                return response()->json(['message' => 'event approved successfully.']);
            }
            return redirect()->route('admin.events.index')->with('success', 'event approved.');
        } catch (Exception $e) {
            if ($request->wantsJson()) {
                return response()->json(['message' => $e->getMessage()], 400);
            }
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }

    /**
     * Admin: Reject/request revision on an event.
     */
    public function reject(event $event, Request $request)
    {
        $this->authorize('adminApprove', $event);

        try {
            // Move to UnderReview if still Submitted
            if ($event->status === \App\Enums\eventStatus::Submitted) {
                $this->eventService->review($event->id);
                $event->refresh();
            }
            $this->eventService->requestRevision($event->id);

            if ($request->wantsJson()) {
                return response()->json(['message' => 'event rejected and revision requested.']);
            }
            return redirect()->route('admin.events.index')->with('success', 'event sent back for revision.');
        } catch (Exception $e) {
            if ($request->wantsJson()) {
                return response()->json(['message' => $e->getMessage()], 400);
            }
            return back()->withErrors(['error' => $e->getMessage()]);
        }
    }
}
