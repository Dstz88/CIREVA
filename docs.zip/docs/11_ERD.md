# CIREVA

# 11_ERD.md
## Entity Relationship Design (ERD)

**Version:** 1.0  
**Project:** CIREVA (Cirebon Event & Virtual Application)

---

# 1. Purpose

Dokumen ini menjelaskan struktur entitas, relasi, dan aturan database yang menjadi dasar implementasi Laravel Migration, Model, Repository, dan Service.

---

# 2. Core Entities

## Authentication
- users
- roles

## Organizer
- organizer_profiles
- organizer_documents
- cooperation_agreements (SPK)

## Event
- event_categories
- event_locations
- events
- event_schedules (Calendar)

## Ticket
- tickets

## Booking
- bookings
- booking_items

## Transaction
- transactions
- payment_proofs

## Reporting
- reports
- activity_logs
- notifications

---

# 3. Relationship

```text
users
 ├── 1──1 organizer_profiles
 ├── 1──N bookings
 ├── 1──N notifications
 └── 1──N activity_logs

organizer_profiles
 ├── 1──N organizer_documents
 ├── 1──N cooperation_agreements
 └── 1──N events

events
 ├── N──1 event_categories
 ├── N──1 event_locations
 ├── 1──N event_schedules
 ├── 1──N tickets
 └── 1──N reports

event_schedules
 └── N──1 events

tickets
 ├── N──1 events
 └── 1──N booking_items

bookings
 ├── N──1 users
 ├── 1──N booking_items
 └── 1──1 transactions

booking_items
 ├── N──1 bookings
 └── N──1 tickets

transactions
 ├── 1──1 bookings
 └── 1──N payment_proofs
```

---

# 4. Key Business Rules

## Organizer
- Setiap Organizer berasal dari satu User.
- Organizer harus memiliki profil lengkap.
- Organizer harus memiliki SPK berstatus **Approved** sebelum membuat Event.

## Event
- Event dimiliki satu Organizer.
- Event memiliki satu Kategori.
- Event memiliki satu Lokasi.
- Event dapat memiliki banyak Jadwal.
- Event dapat memiliki banyak Tiket.

## Calendar
- Satu Event memiliki banyak Jadwal.
- Jadwal pada lokasi yang sama tidak boleh bentrok.
- Jadwal dengan booking tidak boleh dihapus.

## Ticket
- Tiket hanya aktif jika Event berstatus Published.

## Booking
- Satu Booking dapat memiliki beberapa Item Tiket.
- Satu Booking memiliki satu Transaksi.

---

# 5. Suggested Table Order

1. roles
2. users
3. organizer_profiles
4. organizer_documents
5. cooperation_agreements
6. event_categories
7. event_locations
8. events
9. event_schedules
10. tickets
11. bookings
12. booking_items
13. transactions
14. payment_proofs
15. reports
16. notifications
17. activity_logs

---

# 6. Laravel Relationships

- User hasOne OrganizerProfile
- OrganizerProfile belongsTo User
- OrganizerProfile hasMany Events
- OrganizerProfile hasMany CooperationAgreements
- Event belongsTo OrganizerProfile
- Event belongsTo Category
- Event belongsTo Location
- Event hasMany EventSchedules
- Event hasMany Tickets
- Ticket belongsTo Event
- Booking belongsTo User
- Booking hasMany BookingItems
- Booking hasOne Transaction
- Transaction belongsTo Booking

---

# 7. Next Step

Dokumen ini menjadi acuan untuk:
- 04_DATABASE.md
- Laravel Migration
- Eloquent Model
- Foreign Key
- Repository Pattern
- Service Pattern
