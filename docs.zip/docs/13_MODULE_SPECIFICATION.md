# CIREVA

# 13_MODULE_SPECIFICATION.md

**Version:** 1.0  
**Status:** Final Draft

---

# Purpose

Dokumen ini menjelaskan spesifikasi implementasi setiap modul pada CIREVA. Setiap modul memiliki tanggung jawab, route, controller, service, repository, model, policy, middleware, event, dan business rules yang jelas.

---

# 1. Authentication Module

## Purpose
Mengelola autentikasi dan otorisasi pengguna.

### Features
- Register User
- Register Organizer
- Login
- Logout
- Email Verification
- Forgot Password
- Reset Password

### Components
- Controller: AuthController
- Service: AuthenticationService
- Repository: UserRepository
- Models: User, Role
- Middleware: guest, auth, verified

---

# 2. Organizer Module

## Features
- Dashboard
- Organizer Profile
- Upload Supporting Documents
- Organizer Verification Status

### Components
- Controller: OrganizerController
- Service: OrganizerService
- Repository: OrganizerRepository
- Model: OrganizerProfile

### Business Rules
- Profil harus lengkap.
- Dokumen wajib diunggah.
- Status Organizer menentukan akses dashboard.

---

# 3. SPK Module

## Features
- Generate SPK
- View SPK
- Accept Agreement
- Digital Signature
- Download SPK
- SPK History

### Components
- Controller: SpkController
- Service: SpkService
- Repository: SpkRepository
- Model: CooperationAgreement

### Status
Draft → Generated → Pending Signature → Signed → Under Review → Approved / Rejected

---

# 4. Event Module

## Features
- CRUD Event
- Submit Event
- Approval
- Publish
- Archive

### Components
- Controller: EventController
- Service: EventService
- Repository: EventRepository
- Models: Event, EventCategory, EventLocation

### Policy
- Hanya Organizer terverifikasi yang dapat membuat event.

---

# 5. Calendar Module

## Features
- View Calendar
- Input Jadwal
- Update Jadwal
- Delete Jadwal
- Month / Week / Day View
- Timeline View
- Conflict Detection
- Venue Availability

### Components
- Controller: CalendarController
- Service: CalendarService
- Repository: CalendarRepository
- Model: EventSchedule

### Business Rules
- Tidak boleh ada benturan jadwal.
- Jadwal dengan booking tidak dapat dihapus.

---

# 6. Ticket Module

## Features
- Create Ticket
- Update Ticket
- Delete Ticket
- Activate Ticket
- Ticket Availability

### Components
- Controller: TicketController
- Service: TicketService
- Repository: TicketRepository
- Model: Ticket

---

# 7. Booking Module

## Features
- Booking Ticket
- Cancel Booking
- Booking History
- Download E-Ticket

### Components
- Controller: BookingController
- Service: BookingService
- Repository: BookingRepository
- Models: Booking, BookingItem

### Events
- BookingCreated
- BookingCompleted

---

# 8. Transaction Module

## Features
- Payment
- Payment Verification
- Refund (Future)

### Components
- Controller: TransactionController
- Service: TransactionService
- Repository: TransactionRepository
- Models: Transaction, PaymentProof

---

# 9. Notification Module

## Features
- System Notification
- Booking Notification
- SPK Notification
- Event Notification

### Components
- Service: NotificationService
- Model: Notification

---

# 10. Reporting Module

## Features
- Event Report
- Booking Report
- Revenue Report
- Organizer Report

### Components
- Controller: ReportController
- Service: ReportService
- Repository: ReportRepository
- Model: Report

---

# 11. Master Data Module

## Features
- Event Categories
- Event Locations
- User Management

### Components
- Controller: MasterDataController
- Service: MasterDataService

---

# Cross Module Rules

- Organizer harus Approved sebelum membuat Event.
- SPK harus Approved sebelum Event dapat diajukan.
- Event harus Published sebelum Ticket dijual.
- Calendar harus valid sebelum Event dipublikasikan.
- Booking menghasilkan Transaction dan Notification.
- Payment Success menerbitkan E-Ticket.

---

# References

- 01_PRD.md
- 03_ARCHITECTURE.md
- 04_DATABASE.md
- 05_WORKFLOW.md
- 10_ROUTES.md
- 11_ERD.md
- 12_DATABASE_SCHEMA.md
