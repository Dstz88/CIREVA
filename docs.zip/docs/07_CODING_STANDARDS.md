# CIREVA

# 07_CODING_STANDARDS.md

> **Purpose**
>
> Dokumen ini mendefinisikan standar penulisan kode untuk seluruh proyek CIREVA. Semua developer dan AI Assistant wajib mengikuti aturan ini agar implementasi tetap konsisten, mudah dipelihara, dan sesuai dengan praktik terbaik Laravel.

---

# 1. General Principles

Semua kode harus memenuhi prinsip berikut:

- Readability
- Maintainability
- Scalability
- Security
- Reusability
- Simplicity

Prioritaskan kode yang mudah dipahami dibanding kode yang terlalu kompleks.

---

# 2. PHP Standard

Ikuti standar:

- PSR-1
- PSR-12
- PSR-4 (Autoloading)

Gunakan fitur modern PHP 8.3+ apabila sesuai.

---

# 3. Laravel Convention

Gunakan konvensi Laravel sebisa mungkin.

Contoh:

- Resource Controller
- Route Model Binding
- Form Request
- Eloquent Relationship
- Policy
- Notification
- Event & Listener
- Database Transaction

Jangan membuat solusi khusus apabila Laravel telah menyediakan mekanisme yang sesuai.

---

# 4. Project Structure

```text
app/
├── Http/
│   ├── Controllers/
│   ├── Middleware/
│   └── Requests/
├── Models/
├── Services/
├── Repositories/
├── Policies/
├── Events/
├── Listeners/
├── Notifications/
└── Support/

resources/
├── views/
├── css/
└── js/

routes/
database/
tests/
```

---

# 5. Naming Convention

## Class

Gunakan PascalCase.

Contoh:

```
EventService
BookingController
OrganizerRepository
```

---

## Method

Gunakan camelCase.

```
approveEvent()

generateAgreement()

createBooking()
```

---

## Variable

Gunakan camelCase.

```
$event

$booking

$ticketQuota
```

---

## Constant

Gunakan UPPER_SNAKE_CASE.

```
MAX_UPLOAD_SIZE

DEFAULT_STATUS
```

---

## Database

Table:

```
event_categories
```

Column:

```
created_at

organizer_profile_id
```

Migration:

```
create_events_table
```

---

# 6. Controller Rules

Controller hanya bertanggung jawab untuk:

- menerima request
- memanggil service
- mengembalikan response

Controller **tidak boleh**:

- menjalankan query kompleks
- menghitung bisnis proses
- mengubah banyak model secara langsung

Contoh:

```php
public function store(StoreEventRequest $request)
{
    $this->eventService->store($request->validated());

    return redirect()->route('organizer.events.index');
}
```

---

# 7. Form Request Rules

Seluruh validasi input wajib menggunakan Form Request.

Jangan menggunakan:

```php
$request->validate(...)
```

di dalam Controller kecuali untuk kasus yang sangat sederhana.

---

# 8. Service Rules

Seluruh business logic ditempatkan pada Service.

Contoh:

```
EventService

BookingService

SpkService

CalendarService
```

Service harus:

- reusable
- tidak bergantung pada HTTP Request
- mudah diuji

---

# 9. Repository Rules

Repository hanya bertanggung jawab terhadap akses data.

Repository tidak boleh:

- melakukan redirect
- mengakses Request
- berisi business rule

---

# 10. Model Rules

Model digunakan untuk:

- Eloquent Relationship
- Scope
- Accessor
- Mutator
- Cast

Business logic yang kompleks tidak ditempatkan pada Model.

---

# 11. Route Rules

Gunakan Resource Route apabila sesuai.

Contoh:

```php
Route::resource('events', EventController::class);
```

Gunakan nama route yang konsisten.

```
events.index

events.store

events.update
```

---

# 12. Validation Rules

Gunakan:

- Form Request
- Rule Object (jika kompleks)

Validation harus berada di satu tempat.

---

# 13. Database Rules

Gunakan:

- Foreign Key
- Index
- Soft Delete (bila diperlukan)
- Timestamp

Selalu gunakan migration.

Jangan mengubah database secara manual.

---

# 14. Query Rules

Gunakan:

- Eloquent
- Relationship
- Scope

Gunakan Query Builder hanya jika diperlukan.

Hindari N+1 Query.

Gunakan:

```php
with()
```

untuk eager loading.

---

# 15. Transaction Rules

Operasi yang mengubah beberapa tabel wajib menggunakan:

```php
DB::transaction(function () {

});
```

Contoh:

- Booking
- Payment
- Approval
- SPK

---

# 16. Exception Handling

Gunakan Exception apabila:

- proses gagal
- data tidak valid
- resource tidak ditemukan

Jangan menggunakan:

```php
die()

exit()
```

---

# 17. Logging Rules

Gunakan logging untuk:

- error
- warning
- proses penting

Jangan menggunakan:

```php
dd()

dump()
```

pada kode produksi.

---

# 18. Security Rules

Selalu gunakan:

- CSRF Protection
- Authorization
- Policy
- Mass Assignment Protection
- Hash Password
- Validation

Jangan pernah menyimpan password dalam bentuk plain text.

---

# 19. Blade Guidelines

Gunakan Blade Components untuk elemen yang digunakan berulang, seperti:

- Button
- Card
- Badge
- Modal
- Alert
- Form Input

Hindari duplikasi markup.

---

# 20. Tailwind CSS Guidelines

Gunakan utility class Tailwind.

Hindari inline style.

Gunakan komponen reusable untuk tampilan yang sering digunakan.

---

# 21. Comments

Komentar hanya digunakan apabila logika sulit dipahami.

Hindari komentar yang menjelaskan hal yang sudah jelas dari nama method atau variabel.

---

# 22. Testing Guidelines

Semua fitur utama sebaiknya memiliki:

- Feature Test
- Unit Test (untuk business logic)

Minimal pengujian dilakukan pada:

- Authentication
- Booking
- Payment
- Event
- SPK

---

# 23. Git Commit Convention

Gunakan format berikut:

```
feat: add organizer approval

fix: resolve booking validation

refactor: simplify event service

docs: update workflow

test: add booking feature test
```

---

# 24. Code Review Checklist

Sebelum melakukan merge, pastikan:

- Mengikuti PRD
- Mengikuti Workflow
- Mengikuti Database Schema
- Tidak ada business logic di Controller
- Validasi menggunakan Form Request
- Menggunakan Service Layer
- Tidak ada duplikasi kode
- Tidak ada N+1 Query
- Tidak ada `dd()` atau `dump()`
- Lolos pengujian

---

# 25. References

- 02_AI_CONTEXT.md
- 03_ARCHITECTURE.md
- 04_DATABASE.md
- 05_WORKFLOW.md
- 09_DEVELOPMENT_RULES.md
- 12_DATABASE_SCHEMA.md
- 13_MODULE_SPECIFICATION.md