# CIREVA

# 12_DATABASE_SCHEMA.md

**Version:** 1.0  
**Status:** Draft  
**Project:** CIREVA (Cirebon Event & Virtual Application)

---

# 1. Purpose

Dokumen ini menjadi spesifikasi teknis seluruh struktur tabel database CIREVA. Dokumen ini digunakan sebagai acuan pembuatan Laravel Migration, Eloquent Model, Repository, Service, dan validasi ERD.

---

# 2. Database Convention

## Engine
- MySQL 8+
- InnoDB
- utf8mb4
- utf8mb4_unicode_ci

## General Rules

- Primary Key: `id` (BIGINT UNSIGNED)
- Foreign Key: `*_id`
- Timestamp: `created_at`, `updated_at`
- Soft Delete: `deleted_at` (jika diperlukan)

---

# 3. Tables

## roles

| Field | Type | Constraint |
|------|------|------------|
| id | bigint | PK |
| name | varchar(50) | Unique |
| description | varchar(255) | Nullable |

---

## users

| Field | Type | Constraint |
|------|------|------------|
| id | bigint | PK |
| role_id | bigint | FK -> roles |
| name | varchar(150) | Required |
| email | varchar(150) | Unique |
| password | varchar(255) | Required |
| email_verified_at | timestamp | Nullable |
| remember_token | varchar(100) | Nullable |
| created_at | timestamp | |
| updated_at | timestamp | |
| deleted_at | timestamp | Nullable |

Relationship:
- belongsTo(Role)
- hasOne(OrganizerProfile)
- hasMany(Booking)

---

## organizer_profiles

| Field | Type |
|------|------|
| id | bigint |
| user_id | bigint |
| organization_name | varchar(200) |
| owner_name | varchar(150) |
| phone | varchar(30) |
| address | text |
| description | text |
| logo | varchar(255) |
| status | enum(pending,approved,rejected,suspended) |

Relationship:
- belongsTo(User)
- hasMany(OrganizerDocument)
- hasMany(CooperationAgreement)
- hasMany(Event)

---

## organizer_documents

| Field | Type |
|------|------|
| id | bigint |
| organizer_profile_id | bigint |
| document_type | varchar(100) |
| file_path | varchar(255) |
| verification_status | enum(pending,approved,rejected) |

---

## cooperation_agreements (SPK)

| Field | Type |
|------|------|
| id | bigint |
| organizer_profile_id | bigint |
| agreement_number | varchar(100) |
| version | varchar(20) |
| file_path | varchar(255) |
| signed_at | datetime |
| approved_at | datetime |
| status | enum(draft,generated,pending_signature,signed,under_review,revision_required,approved,rejected,expired) |

---

## event_categories

| Field | Type |
|------|------|
| id | bigint |
| name | varchar(100) |
| slug | varchar(120) |

---

## event_locations

| Field | Type |
|------|------|
| id | bigint |
| name | varchar(150) |
| address | text |
| latitude | decimal(10,7) |
| longitude | decimal(10,7) |

---

## events

| Field | Type |
|------|------|
| id | bigint |
| organizer_profile_id | bigint |
| category_id | bigint |
| location_id | bigint |
| title | varchar(200) |
| slug | varchar(220) |
| description | longtext |
| banner | varchar(255) |
| status | enum(draft,submitted,under_review,revision_required,approved,published,ongoing,finished,archived) |
| published_at | datetime |

Relationship:
- belongsTo Organizer
- belongsTo Category
- belongsTo Location
- hasMany EventSchedules
- hasMany Tickets

---

## event_schedules (Calendar)

| Field | Type |
|------|------|
| id | bigint |
| event_id | bigint |
| start_datetime | datetime |
| end_datetime | datetime |
| timezone | varchar(50) |
| status | enum(draft,scheduled,published,ongoing,finished,cancelled) |

Business Rule:
- Tidak boleh bentrok pada lokasi dan waktu yang sama.

---

## tickets

| Field | Type |
|------|------|
| id | bigint |
| event_id | bigint |
| name | varchar(150) |
| price | decimal(12,2) |
| quota | integer |
| sold | integer |
| status | enum(active,inactive,sold_out) |

---

## bookings

| Field | Type |
|------|------|
| id | bigint |
| user_id | bigint |
| booking_code | varchar(50) |
| total_amount | decimal(12,2) |
| status | enum(pending,paid,cancelled,completed,expired) |

---

## booking_items

| Field | Type |
|------|------|
| id | bigint |
| booking_id | bigint |
| ticket_id | bigint |
| quantity | integer |
| price | decimal(12,2) |

---

## transactions

| Field | Type |
|------|------|
| id | bigint |
| booking_id | bigint |
| payment_method | varchar(50) |
| amount | decimal(12,2) |
| status | enum(pending,success,failed,refunded) |
| paid_at | datetime |

---

## payment_proofs

| Field | Type |
|------|------|
| id | bigint |
| transaction_id | bigint |
| file_path | varchar(255) |
| verified_by | bigint |
| verified_at | datetime |

---

## notifications

| Field | Type |
|------|------|
| id | bigint |
| user_id | bigint |
| title | varchar(200) |
| message | text |
| is_read | boolean |

---

## reports

| Field | Type |
|------|------|
| id | bigint |
| report_type | varchar(100) |
| generated_by | bigint |
| generated_at | datetime |

---

## activity_logs

| Field | Type |
|------|------|
| id | bigint |
| user_id | bigint |
| module | varchar(100) |
| action | varchar(100) |
| description | text |
| ip_address | varchar(45) |

---

# 4. Migration Order

1. roles
2. users
3. organizer_profiles
4. organizer_documents
5. cooperation_agreements
6. event_categories
7. event_locations
8. events
9. event_schedules
10. tickets
11. bookings
12. booking_items
13. transactions
14. payment_proofs
15. notifications
16. reports
17. activity_logs

---

# 5. References

- 01_PRD.md
- 04_DATABASE.md
- 11_ERD.md
- 05_WORKFLOW.md
