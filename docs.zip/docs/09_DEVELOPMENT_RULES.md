# CIREVA

# 09_DEVELOPMENT_RULES.md

> **Purpose**
>
> Dokumen ini mendefinisikan aturan pengembangan proyek CIREVA. Seluruh developer dan AI Assistant wajib mengikuti aturan ini untuk menjaga konsistensi implementasi, kualitas perangkat lunak, dan keselarasan dengan kebutuhan bisnis.

---

# 1. General Rules

Seluruh pengembangan harus mengacu pada dokumentasi resmi proyek.

Urutan referensi:

1. 01_PRD.md
2. 05_WORKFLOW.md
3. 12_DATABASE_SCHEMA.md
4. 13_MODULE_SPECIFICATION.md
5. 03_ARCHITECTURE.md
6. 04_DATABASE.md
7. 10_ROUTES.md
8. 11_ERD.md
9. 07_CODING_STANDARDS.md

Jika terdapat konflik, gunakan dokumen dengan prioritas yang lebih tinggi.

---

# 2. Development Principles

Seluruh implementasi harus memenuhi prinsip:

- Modular
- Maintainable
- Reusable
- Secure
- Scalable
- Testable

---

# 3. Documentation First

Sebelum mengembangkan fitur baru, pastikan:

- kebutuhan sudah tercantum di PRD
- workflow sudah terdokumentasi
- database telah dirancang
- module specification tersedia

Jangan membuat fitur baru hanya berdasarkan asumsi.

---

# 4. Workflow Compliance

Seluruh perubahan status harus mengikuti workflow resmi.

Contoh:

Organizer

```
Pending
↓
Approved
```

Event

```
Draft
↓
Submitted
↓
Under Review
↓
Approved
↓
Published
↓
Finished
```

Booking

```
Pending
↓
Paid
↓
Completed
```

Dilarang melewati tahapan workflow tanpa alasan bisnis yang jelas.

---

# 5. Feature Development Process

Urutan implementasi fitur:

1. Analisis kebutuhan
2. Validasi workflow
3. Validasi database
4. Buat migration (jika diperlukan)
5. Buat model
6. Buat repository
7. Buat service
8. Buat form request
9. Buat controller
10. Buat view
11. Tambahkan route
12. Lakukan pengujian
13. Perbarui dokumentasi bila ada perubahan

---

# 6. Database Rules

- Seluruh perubahan database menggunakan migration.
- Jangan mengubah struktur database secara langsung.
- Gunakan foreign key jika terdapat relasi.
- Gunakan transaction untuk perubahan pada beberapa tabel.
- Pastikan migration dapat dijalankan berulang tanpa konflik.

---

# 7. Business Logic Rules

Business logic wajib ditempatkan pada Service Layer.

Dilarang menempatkan business logic di:

- Controller
- Blade View
- Repository
- Route

---

# 8. Authorization Rules

Setiap fitur harus mempertimbangkan hak akses.

Gunakan:

- Middleware
- Policy
- Gate (jika diperlukan)

Hak akses minimal:

- Guest
- User
- Organizer
- Administrator

---

# 9. Validation Rules

Semua input harus divalidasi menggunakan Form Request.

Validasi harus mencakup:

- Required
- Format
- Tipe data
- Panjang karakter
- Keunikan data
- Relasi antar data

---

# 10. Error Handling

Kesalahan harus ditangani dengan baik.

Gunakan:

- Exception
- Logging
- Pesan yang jelas kepada pengguna

Jangan menampilkan detail teknis (stack trace) pada lingkungan produksi.

---

# 11. Security Rules

Selalu pastikan:

- Password di-hash.
- CSRF aktif.
- Validasi input dilakukan.
- Otorisasi diperiksa.
- Mass Assignment dicegah.
- Upload file divalidasi.

---

# 12. UI Development Rules

Seluruh halaman harus mengikuti:

- 06_UI_GUIDELINE.md

Gunakan komponen yang dapat digunakan kembali.

Hindari duplikasi tampilan.

---

# 13. Performance Rules

- Gunakan eager loading untuk relasi.
- Hindari N+1 Query.
- Gunakan pagination pada data besar.
- Hindari query di dalam loop.
- Optimalkan query sebelum menambahkan cache.

---

# 14. File Organization

Setiap fitur baru harus ditempatkan pada lokasi yang sesuai.

Contoh:

```
Controller
↓

Service
↓

Repository
↓

Model
↓

View
```

Jangan mencampur tanggung jawab antar layer.

---

# 15. Refactoring Rules

Refactoring diperbolehkan apabila:

- meningkatkan keterbacaan
- mengurangi duplikasi
- meningkatkan performa
- mempermudah pengujian

Refactoring tidak boleh mengubah perilaku bisnis tanpa persetujuan.

---

# 16. Testing Rules

Setiap fitur utama harus diuji.

Minimal:

- Authentication
- Organizer
- SPK
- Event
- Ticket
- Booking
- Payment

Bug yang ditemukan harus diperbaiki sebelum fitur dinyatakan selesai.

---

# 17. Logging Rules

Catat aktivitas penting, seperti:

- Login
- Approval Organizer
- Approval SPK
- Publish Event
- Booking
- Payment

Log digunakan untuk audit dan debugging.

---

# 18. Change Management

Perubahan berikut harus disertai pembaruan dokumentasi:

- Workflow
- Database
- Route
- Module Specification
- Business Rule

Dokumentasi harus tetap sinkron dengan implementasi.

---

# 19. AI Development Rules

AI Assistant harus:

- membaca dokumentasi sebelum menghasilkan kode
- tidak membuat asumsi baru
- menjaga konsistensi dengan arsitektur proyek
- menghindari perubahan di luar ruang lingkup permintaan
- menjelaskan dampak perubahan jika memengaruhi modul lain

---

# 20. Definition of Done

Sebuah fitur dianggap selesai apabila:

- sesuai PRD
- mengikuti workflow
- sesuai database schema
- mengikuti coding standards
- lolos pengujian
- tidak menghasilkan error
- dokumentasi diperbarui jika diperlukan
- telah melalui code review

---

# 21. References

- 01_PRD.md
- 03_ARCHITECTURE.md
- 04_DATABASE.md
- 05_WORKFLOW.md
- 06_UI_GUIDELINE.md
- 07_CODING_STANDARDS.md
- 10_ROUTES.md
- 12_DATABASE_SCHEMA.md
- 13_MODULE_SPECIFICATION.md